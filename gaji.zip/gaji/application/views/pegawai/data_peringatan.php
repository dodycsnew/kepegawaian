<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>

    <table class="table table-hover table-bordered table-dark">
        <tr>
            <th>Nama Karyawan</th>
            <th>NIK</th>
            <th>Tanggal Peringatan</th>
            <th>Jenis Peringatan</th>
            <th>Keterangan</th>

        </tr>

        <?php foreach ($data_peringatan as $dp) : ?>
            <tr class="table-warning text-dark">
                <td class="text-center"><?php echo $dp['nama_pegawai']; ?></td>
                <td class="text-center"><?php echo $dp['nik']; ?></td>
                <td class="text-center"><?php echo $dp['tgl_peringatan']; ?></td>
                <td class="text-center"><?php echo $dp['jenis_peringatan']; ?></td>
                <td class="text-center"><?php echo $dp['keterangan']; ?></td>

            </tr>
        <?php endforeach; ?>
    </table>

</div>
<!-- /.container-fluid -->