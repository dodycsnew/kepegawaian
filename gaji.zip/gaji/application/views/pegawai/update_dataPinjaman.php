<!-- Begin Page Content -->
<div class="container-fluid">

	<!-- Page Heading -->
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
	</div>

</div>
<!-- /.container-fluid -->

<div class="card" style="width: 60% ; margin-bottom: 100px">
	<div class="card-body">
		<?php foreach ($data_pinjaman as $dp) : ?>
			<form method="POST" action="<?php echo base_url('pegawai/data_pinjaman/update_data_aksi/') ?>" enctype="multipart/form-data">
				<div class="form-group">
					<label>Nama Karyawan</label>
					<input type="text" name="nama_pegawai" class="form-control" readonly value="<?php echo $dp->nama_pegawai ?>">
					<?php echo form_error('nama_pegawai', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Tanggal Pembayaran</label>
					<input type="hidden" name="id_pinjaman" class="form-control" value="<?php echo $dp->id_pinjaman ?>">
					<input type="hidden" name="id_pegawai" class="form-control" value="<?php echo $dp->id_pegawai ?>">
					<input type="text" name="tgl_pembayaran" class="form-control" value="<?php echo date('d/m/y'); ?>" readonly>
					<?php echo form_error('tgl_pinjaman', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Jumlah Bayar</label>
					<input type="text" name="jumlah_bayar" class="form-control" value="<?php echo $dp->jumlah_bayar ?>">
					<?php echo form_error('jumlah_bayar', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Keterangan Bayar</label>
					<input type="text" name="keterangan_bayar" class="form-control" value="<?php echo $dp->keterangan ?>">
					<?php echo form_error('keterangan', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Bukti Pembayaran</label>
					<input type="file" name="photo" class="form-control">
				</div>

				<button type="submit" class="btn btn-success">Simpan</button>

				<a href="<?php echo base_url('pegawai/data_pinjaman') ?>" class="btn btn-warning">Kembali</a>

			</form>
		<?php endforeach; ?>
	</div>
</div>