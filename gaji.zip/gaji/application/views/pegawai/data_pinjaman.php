<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>
    <a class="btn btn-sm btn-success mb-3" href="<?php echo base_url('pegawai/data_pinjaman/tambah_data') ?>"><i class="fas fa-plus"></i> Tambah Pinjaman</a>
    <?php echo $this->session->flashdata('pesan') ?>
</div>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
            + Lakukan Pembayaran
        </button>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Karyawan</th>
                            <th class="text-center">NIK</th>
                            <th class="text-center">Tanggal Pinjaman</th>
                            <th class="text-center">Jumlah Pinjaman</th>
                            <th class="text-center">Bukti Pinjaman</th>
                            <th class="text-center">Jumlah Bayar</th>
                            <th class="text-center">Tanggal Pembayar</th>
                            <th class="text-center">Sisa Pinjaman</th>
                            <th class="text-center">Bukti Pembayaran</th>
                            <th class="text-center">Keterangan</th>
                            <th class="text-center">Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($data_pinjaman as $dp) : ?>

                            <tr>
                                <td class="text-center"><?php echo $no++ ?></td>
                                <td class="text-center"><?php echo $dp['nama_pegawai']; ?></td>
                                <td class="text-center"><?php echo $dp['nik']; ?></td>
                                <td class="text-center"><?php echo $dp['tgl_pinjaman']; ?></td>
                                <td class="text-center"><?php echo number_format($dp['jumlah_pinjaman']);  ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('photo/bukti_pinjaman/') . $dp['bukti_pinjaman']; ?>" target="_blank"><img src="<?php echo base_url() . 'photo/bukti_pinjaman/' . $dp['bukti_pinjaman']; ?>" width="50px"></img> </a>
                                </td>
                                <td class="text-center"><?php echo $dp['jumlah_bayar']; ?></td>

                                <td>
                                    <?php
                                    if ($dp['tgl_pembayaran'] == 0) {
                                        echo "Belum Bayar";
                                    } else {
                                        echo $dp['tgl_pembayaran'];
                                    }
                                    ?>
                                </td>

                                <td class="text-center"><?php echo number_format($dp['jumlah_bayar'] - $dp['jumlah_pinjaman']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('photo/bukti_pembayaran') . $dp['bukti_pembayaran']; ?>" target="_blank"><img src="<?php echo base_url() . 'photo/bukti_pembayaran/' . $dp['bukti_pembayaran']; ?>" width="50px"></img> </a>
                                </td>
                                <td class="text-center"><?php echo $dp['keterangan']; ?></td>
                                <td>
                                    <center>
                                        <a class="btn btn-sm btn-info" href="<?php echo base_url('pegawai/data_pinjaman/update_data/' . $dp['id_pinjaman']) ?>"><i class="fas fa-edit"></i></a>
                                    </center>
                                </td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="<?= base_url("pegawai/data_pinjaman/tambah_data"); ?>" enctype="multipart/form-data">
            <?php foreach ($data_pinjaman as $dp) : ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Pembayar Pinjaman</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>


                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Karyawan</label>
                            <input type="text" name="nama_pegawai" class="form-control" readonly value="<?php echo $dp['nama_pegawai']; ?>">
                            <input type="hidden" name="id_pinjaman" class="form-control" value="<?php echo $dp['id_pinjaman']; ?>">
                            <input type="hidden" name="id_pegawai" class="form-control" value="<?php echo $dp['id_pegawai']; ?>">
                            <?php echo form_error('nama_pegawai', '<div class="text-small text-danger"> </div>') ?>
                        </div>

                        <div class="form-group">
                            <label>Jumlah Pembayaran</label>
                            <input type="number" name="jumlah_bayar" class="form-control">
                            <?php echo form_error('jumlah_bayar', '<div class="text-small text-danger"> </div>') ?>
                        </div>

                        <div class="form-group">
                            <label>Tanggal Pembayaran</label>
                            <input type="text" name="tgl_pembayaran" class="form-control" value="<?php echo date('d/m/y'); ?>" readonly>
                            <?php echo form_error('tgl_pembayaran', '<div class="text-small text-danger"> </div>') ?>
                        </div>

                        <div class="form-group">
                            <label>Keterangan Pembayaran</label>
                            <input type="text" name="keterangan_bayar" class="form-control" value="<?php echo $dp['keterangan_bayar']; ?>">
                            <?php echo form_error('keterangan_bayar', '<div class="text-small text-danger"> </div>') ?>
                        </div>

                        <div class="form-group">
                            <label>Bukti Pembayaran</label>
                            <input type="file" name="photo" class="form-control">
                        </div>

                    </div>


                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </form>
    </div>
</div>