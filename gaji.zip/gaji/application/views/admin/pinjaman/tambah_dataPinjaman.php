<!-- Begin Page Content -->
<div class="container-fluid">

	<!-- Page Heading -->
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
	</div>

</div>
<!-- /.container-fluid -->

<div class="card" style="width: 60% ; margin-bottom: 100px">
	<div class="card-body">
		<form method="POST" action="<?php echo base_url('admin/data_pinjaman/tambah_data_aksi') ?>" enctype="multipart/form-data">

			<div class="form-group">
				<label>Nama Karyawan</label>
				<select class="form-control" data-live-search="true" id="id_pegawai" name="id_pegawai">
					<option selected="0">Pilih Karyawan</option>
					<?php foreach ($users as $u) : ?>
						<option value="<?php echo $u['id_pegawai']; ?>"> <?php echo $u['nama_pegawai']; ?> (<?php echo $u['nik']; ?>)</option>
					<?php endforeach; ?>
				</select>
				<?php echo form_error('id_pegawai', '<div class="text-small text-danger"> </div>') ?>
			</div>


			<div class="form-group">
				<label>Tanggal Pinjaman</label>
				<input type="date" name="tgl_pinjaman" class="form-control">
				<?php echo form_error('tgl_pinjaman', '<div class="text-small text-danger"> </div>') ?>
			</div>

			<div class="form-group">
				<label>Jumlah Pinjaman</label>
				<input type="number" name="jumlah_pinjaman" class="form-control">
				<?php echo form_error('jumlah_pinjaman', '<div class="text-small text-danger"> </div>') ?>
			</div>

			<div class="form-group">
				<label>Bukti Pinjaman</label>
				<input type="file" name="photo" class="form-control">
			</div>


			<div class="form-group">
				<label>Keterangan</label>
				<input type="text" name="keterangan" class="form-control">
				<?php echo form_error('keterangan', '<div class="text-small text-danger"> </div>') ?>
			</div>


			<button type="submit" class="btn btn-success">Simpan</button>
			<button type="reset" class="btn btn-danger">Reset</button>
			<a href="<?php echo base_url('admin/data_pinjaman') ?>" class="btn btn-warning">Kembali</a>

		</form>
	</div>
</div>