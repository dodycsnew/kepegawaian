<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>
    <a class="btn btn-sm btn-success mb-3" href="<?php echo base_url('admin/data_pinjaman/tambah_data') ?>"><i class="fas fa-plus"></i> Tambah Data Pinjaman</a>
    <?php echo $this->session->flashdata('pesan') ?>
</div>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Karyawan</th>
                            <th class="text-center">NIK</th>
                            <th class="text-center">Tanggal Pinjaman</th>
                            <th class="text-center">Jumlah Pinjaman</th>
                            <th class="text-center">Bukti Pinjaman</th>
                            <th class="text-center">Jumlah Bayar</th>
                            <th class="text-center">Tanggal Pembayar</th>
                            <th class="text-center">Sisa Pinjaman</th>
                            <th class="text-center">Bukti Pembayaran</th>
                            <th class="text-center">Keterangan</th>
                            <th class="text-center">Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($data_pinjaman as $dp) : ?>

                            <tr>
                                <td class="text-center"><?php echo $no++ ?></td>
                                <td class="text-center"><?php echo $dp['nama_pegawai']; ?></td>
                                <td class="text-center"><?php echo $dp['nik']; ?></td>
                                <td class="text-center"><?php echo $dp['tgl_pinjaman']; ?></td>
                                <td class="text-center"><?php echo number_format($dp['jumlah_pinjaman']);  ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('photo/bukti_pinjaman/') . $dp['bukti_pinjaman']; ?>" target="_blank"><img src="<?php echo base_url() . 'photo/bukti_pinjaman/' . $dp['bukti_pinjaman']; ?>" width="50px"></img> </a>
                                </td>
                                <td class="text-center"><?php echo $dp['jumlah_bayar']; ?></td>

                                <td>
                                    <?php
                                    if ($dp['tgl_pembayaran'] == 0) {
                                        echo "Belum Bayar";
                                    } else {
                                        echo $dp['tgl_pembayaran'];
                                    }
                                    ?>
                                </td>

                                <td class="text-center"><?php echo number_format($dp['jumlah_bayar'] - $dp['jumlah_pinjaman']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('photo/bukti_pembayaran') . $dp['bukti_pembayaran']; ?>" target="_blank"><img src="<?php echo base_url() . 'photo/bukti_pembayaran/' . $dp['bukti_pembayaran']; ?>" width="50px"></img> </a>
                                </td>
                                <td class="text-center"><?php echo $dp['keterangan']; ?></td>
                                <td>
                                    <center>
                                        <a class="btn btn-sm btn-info" href="<?php echo base_url('admin/data_pinjaman/update_data/' . $dp['id_pinjaman']) ?>"><i class="fas fa-edit"></i></a>
                                        <a onclick="return confirm('Yakin Hapus?')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/data_pinjaman/delete_data/' . $dp['id_pinjaman']) ?>"><i class="fas fa-trash"></i></a>
                                    </center>
                                </td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>