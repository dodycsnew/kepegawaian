<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>

</div>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Karyawan</th>
                            <th class="text-center">NIK</th>
                            <th class="text-center">Tanggal Mulai</th>
                            <th class="text-center">Tanggal Akhir</th>
                            <th class="text-center">Keterangan</th>
                            <th class="text-center">Status Karyawan</th>
                            <th class="text-center">Status Cuti</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($cuti as $c) : ?>

                            <tr>
                                <td class="text-center"><?php echo $no++ ?></td>
                                <td class="text-center"><?php echo $c['nama_pegawai']; ?></td>
                                <td class="text-center"><?php echo $c['nik']; ?></td>
                                <td class="text-center"><?php echo $c['tgl_mulai']; ?></td>
                                <td class="text-center"><?php echo $c['tgl_akhir']; ?></td>
                                <td class="text-center"><?php echo $c['keterangan']; ?></td>
                                <td class="text-center"><?php echo $c['status']; ?></td>

                                <td>
                                    <?php
                                    if ($c['statuss'] == 0) {
                                        echo "PENDING";
                                    } else if ($c['statuss'] == 1) {
                                        echo "DITERIMA";
                                    } else {
                                        echo "DITOLAK";
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="<?= base_url("admin/data_cuti/edit_cuti/1_" . $c['id_cuti']); ?>"><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModals<?= $no; ?>">TERIMA</button></a>
                                    <a href="<?= base_url("admin/data_cuti/edit_cuti/2_" . $c['id_cuti']); ?>"><button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModalss<?= $no; ?>">TOLAK</button></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>