<!-- Begin Page Content -->
<div class="container-fluid">

	<!-- Page Heading -->
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
	</div>

</div>
<!-- /.container-fluid -->

<div class="card" style="width: 60% ; margin-bottom: 100px">
	<div class="card-body">
		<?php foreach ($data_peringatan as $dp) : ?>
			<form method="POST" action="<?php echo base_url('admin/data_peringatan/update_data_aksi/') ?>">
				<div class="form-group">
					<label>Nama Karyawan</label>
					<input type="text" name="nama_pegawai" class="form-control" readonly value="<?php echo $dp->nama_pegawai ?>">
					<?php echo form_error('nama_pegawai', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Tanggal Peringatan</label>
					<input type="hidden" name="id_peringatan" class="form-control" value="<?php echo $dp->id_peringatan ?>">
					<input type="hidden" name="id_pegawai" class="form-control" value="<?php echo $dp->id_pegawai ?>">
					<input type="text" name="tgl_peringatan" class="form-control" value="<?php echo $dp->tgl_peringatan ?>">
					<?php echo form_error('tgl_peringatan', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Jenis Peringatan</label>
					<input type="text" name="jenis_peringatan" class="form-control" value="<?php echo $dp->jenis_peringatan ?>">
					<?php echo form_error('jenis_peringatan', '<div class="text-small text-danger"> </div>') ?>
				</div>

				<div class="form-group">
					<label>Keterangan</label>
					<input type="text" name="keterangan" class="form-control" value="<?php echo $dp->keterangan ?>">
					<?php echo form_error('keterangan', '<div class="text-small text-danger"> </div>') ?>
				</div>



				<button type="submit" class="btn btn-success">Simpan</button>

				<a href="<?php echo base_url('admin/data_peringatan') ?>" class="btn btn-warning">Kembali</a>

			</form>
		<?php endforeach; ?>
	</div>
</div>