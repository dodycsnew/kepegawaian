<?php

class Data_Cuti extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if ($this->session->userdata('hak_akses') != '1') {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Anda Belum Login!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('login');
		}
	}

	public function index()
	{
		$data['title'] = "Data Cuti";
		$data['jabatan'] = $this->ModelPenggajian->get_data('data_jabatan')->result();


		$this->db->select('*');
		$this->db->from('data_cuti');
		$this->db->join('data_pegawai', 'data_cuti.id_user=data_pegawai.id_pegawai ', 'inner');
		$data['cuti'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();
		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/cuti/data_cuti', $data);
		$this->load->view('template_admin/footer');
	}

	public function edit_cuti($a)
	{
		$get = [ //menyiapkan data untuk di insert ke database !
			'statuss' => explode("_", $a)[0],
		];
		$this->db->where('id_cuti', explode("_", $a)[1]);
		$this->db->update('data_cuti', $get);
		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data berhasil diubah
            </div>');
		redirect('admin/data_cuti');
	}
}
