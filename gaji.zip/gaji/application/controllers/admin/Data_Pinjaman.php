<?php

class Data_Pinjaman extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if ($this->session->userdata('hak_akses') != '1') {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Anda Belum Login!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('login');
		}
	}

	public function index()
	{
		$data['title'] = "Data Pinjaman";
		$data['jabatan'] = $this->ModelPenggajian->get_data('data_jabatan')->result();


		$this->db->select('*');
		$this->db->from('data_pinjaman');
		$this->db->join('data_pegawai', 'data_pinjaman.id_pegawai=data_pegawai.id_pegawai ', 'inner');
		$data['data_pinjaman'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();
		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/pinjaman/data_pinjaman', $data);
		$this->load->view('template_admin/footer');
	}

	public function tambah_data()
	{
		$data['title'] = "Tambah Data Pinjaman";
		$this->db->select('*');
		$this->db->from('data_pinjaman');
		$this->db->join('data_pegawai', 'data_pinjaman.id_pegawai=data_pegawai.id_pegawai ', 'inner');
		$data['data_pinjaman'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();

		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/pinjaman/tambah_dataPinjaman', $data);
		$this->load->view('template_admin/footer');
	}

	public function tambah_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->tambah_data();
		} else {
			$id_pegawai	= $this->input->post('id_pegawai');
			$tgl_pinjaman		= $this->input->post('tgl_pinjaman');
			$jumlah_pinjaman	= $this->input->post('jumlah_pinjaman');
			$keterangan		= $this->input->post('keterangan');
			$photo			= $_FILES['photo']['name'];
			if ($photo = '') {
			} else {
				$config['upload_path'] 		= './photo/bukti_pinjaman';
				$config['allowed_types'] 	= 'jpg|jpeg|png|tiff';
				$config['max_size']			= 	2048;
				$config['file_name']		= 	'pinjaman-' . date('ymd') . '-' . substr(md5(rand()), 0, 10);
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('photo')) {
					echo "Photo Gagal Diupload !";
				} else {
					$photo = $this->upload->data('file_name');
				}
			}

			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_pinjaman' 	=> $tgl_pinjaman,
				'jumlah_pinjaman' 	=> $jumlah_pinjaman,
				'keterangan' 	=> $keterangan,
				'bukti_pinjaman' => $photo,
			);

			$this->ModelPenggajian->insert_data($data, 'data_pinjaman');
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil ditambahkan!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('admin/data_pinjaman');
		}
	}


	public function update_data($id)
	{
		$where = array('id_pinjaman' => $id);
		$data['data_pinjaman'] = $this->db->query("SELECT * FROM data_pinjaman JOIN data_pegawai ON data_pinjaman.id_pegawai = data_pegawai.id_pegawai WHERE id_pinjaman= '$id'")->result();

		$data['title'] = "Update Data Pinjaman";

		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/pinjaman/update_dataPinjaman', $data);
		$this->load->view('template_admin/footer');
	}

	public function update_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update_data();
		} else {
			$id				= $this->input->post('id_pinjaman');
			$id_pegawai		= $this->input->post('id_pegawai');
			$tgl_pinjaman	= $this->input->post('tgl_pinjaman');
			$jumlah_pinjaman		= $this->input->post('jumlah_pinjaman');
			$keterangan	= $this->input->post('keterangan');
			$photo			= $_FILES['photo']['name'];
			if ($photo = '') {
			} else {
				$config['upload_path'] 		= './photo/bukti_pinjaman';
				$config['allowed_types'] 	= 'jpg|jpeg|png|tiff';
				$config['max_size']			= 	2048;
				$config['file_name']		= 	'pinjaman-' . date('ymd') . '-' . substr(md5(rand()), 0, 10);
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('photo')) {
					echo "Photo Gagal Diupload !";
				} else {
					$photo = $this->upload->data('file_name');
				}
			}



			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_pinjaman' 	=> $tgl_pinjaman,
				'jumlah_pinjaman' 	=> $jumlah_pinjaman,
				'keterangan' 	=> $keterangan,
				'bukti_pinjaman' => $photo,

			);

			$where = array(
				'id_pinjaman' => $id
			);

			$this->ModelPenggajian->update_data('data_pinjaman', $data, $where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil diupdate!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('admin/data_pinjaman');
		}
	}

	public function delete_data($id)
	{
		$where = array('id_pinjaman' => $id);
		$this->ModelPenggajian->delete_data($where, 'data_pinjaman');
		$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Data berhasil dihapus!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
		redirect('admin/data_pinjaman');
	}

	public function _rules()
	{
		$this->form_validation->set_rules('id_pegawai', 'Id Pegawai', 'required');
		$this->form_validation->set_rules('tgl_pinjaman', 'Tgl Pinjaman', 'required');
		$this->form_validation->set_rules('jumlah_pinjaman', 'Jumlah Pinjaman', 'required');
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
	}
}
