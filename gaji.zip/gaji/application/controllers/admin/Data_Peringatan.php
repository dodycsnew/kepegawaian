<?php

class Data_Peringatan extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if ($this->session->userdata('hak_akses') != '1') {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Anda Belum Login!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('login');
		}
	}

	public function index()
	{
		$data['title'] = "Data Peringatan";
		$data['jabatan'] = $this->ModelPenggajian->get_data('data_jabatan')->result();


		$this->db->select('*');
		$this->db->from('data_peringatan');
		$this->db->join('data_pegawai', 'data_peringatan.id_pegawai=data_pegawai.id_pegawai ', 'inner');
		$data['peringatan'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();
		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/peringatan/data_peringatan', $data);
		$this->load->view('template_admin/footer');
	}

	public function tambah_data()
	{
		$data['title'] = "Tambah Data Peringatan";
		$this->db->select('*');
		$this->db->from('data_peringatan');
		$this->db->join('data_pegawai', 'data_peringatan.id_pegawai=data_pegawai.id_pegawai ', 'inner');
		$data['peringatan'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();

		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/peringatan/tambah_dataPeringatan', $data);
		$this->load->view('template_admin/footer');
	}

	public function tambah_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->tambah_data();
		} else {
			$id_pegawai	= $this->input->post('id_pegawai');
			$tgl_peringatan		= $this->input->post('tgl_peringatan');
			$jenis_peringatan	= $this->input->post('jenis_peringatan');
			$keterangan		= $this->input->post('keterangan');

			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_peringatan' 	=> $tgl_peringatan,
				'jenis_peringatan' 	=> $jenis_peringatan,
				'keterangan' 	=> $keterangan,
			);

			$this->ModelPenggajian->insert_data($data, 'data_peringatan');
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil ditambahkan!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('admin/data_peringatan');
		}
	}


	public function update_data($id)
	{
		$where = array('id_peringatan' => $id);
		$data['data_peringatan'] = $this->db->query("SELECT * FROM data_peringatan JOIN data_pegawai ON data_peringatan.id_pegawai = data_pegawai.id_pegawai WHERE id_peringatan= '$id'")->result();

		$data['title'] = "Update Data Peringatan";

		$this->load->view('template_admin/header', $data);
		$this->load->view('template_admin/sidebar');
		$this->load->view('admin/peringatan/update_dataPeringatan', $data);
		$this->load->view('template_admin/footer');
	}

	public function update_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update_data();
		} else {
			$id				= $this->input->post('id_peringatan');
			$id_pegawai		= $this->input->post('id_pegawai');
			$tgl_peringatan	= $this->input->post('tgl_peringatan');
			$jenis_peringatan		= $this->input->post('jenis_peringatan');
			$keterangan	= $this->input->post('keterangan');


			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_peringatan' 	=> $tgl_peringatan,
				'jenis_peringatan' 	=> $jenis_peringatan,
				'keterangan' 	=> $keterangan,

			);

			$where = array(
				'id_peringatan' => $id
			);

			$this->ModelPenggajian->update_data('data_peringatan', $data, $where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil diupdate!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('admin/data_peringatan');
		}
	}

	public function delete_data($id)
	{
		$where = array('id_peringatan' => $id);
		$this->ModelPenggajian->delete_data($where, 'data_peringatan');
		$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Data berhasil dihapus!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
		redirect('admin/data_peringatan');
	}

	public function _rules()
	{
		$this->form_validation->set_rules('id_pegawai', 'Id Pegawai', 'required');
		$this->form_validation->set_rules('tgl_peringatan', 'Tgl Peringatan', 'required');
		$this->form_validation->set_rules('jenis_peringatan', 'Jenis Peringatan', 'required');
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
	}
}
