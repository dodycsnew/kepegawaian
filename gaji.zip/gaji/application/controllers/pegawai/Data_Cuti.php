<?php

class Data_Cuti extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if ($this->session->userdata('hak_akses') != '2') {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Anda Belum Login!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('login');
		}
	}
	public function index()
	{
		$data['title'] = "Data Pengajuan Cuti";
		$id_pegawai = $this->session->userdata('id_pegawai');
		$data['cuti'] = $this->db->query("SELECT * FROM data_cuti JOIN data_pegawai ON data_cuti.id_user = data_pegawai.id_pegawai  WHERE data_cuti.id_user='$id_pegawai'")->result_array();

		$data['users'] = $this->db->get('data_pegawai')->result_array();

		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/data_cuti', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function tambah_data()
	{
		$data['title'] = "Tambah Data Pengajuan Cuti";
		$get = [ //menyiapkan data untuk di insert ke database !
			'id_user' => $this->input->post('id_user'),
			'tgl_mulai' => $this->input->post('tgl_mulai'),
			'tgl_akhir' => $this->input->post('tgl_akhir'),
			'keterangan' => $this->input->post('keterangan'),
		];
		$this->db->insert('data_cuti', $get);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
		<strong>Data berhasil ditambahkan!</strong>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
		</button>
		</div>');
		redirect('pegawai/data_cuti');
	}
}
