<?php

class Data_Pinjaman extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if ($this->session->userdata('hak_akses') != '2') {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Anda Belum Login!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('login');
		}
	}
	/*
	public function index()
	{
		$data['title'] = "Data Pinjaman";
		$id_pegawai = $this->session->userdata('id_pegawai');
		$data['data_pinjaman'] = $this->db->query("SELECT * FROM data_pinjaman JOIN data_pegawai ON data_pinjaman.id_pegawai = data_pegawai.id_pegawai  WHERE data_pinjaman.id_pegawai='$id_pegawai'")->result_array();


		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/data_pinjaman', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function tambah_data()
	{

		$data['title'] = "Pembayaran Pinjaman";
		$get = [ //menyiapkan data untuk di insert ke database !
			'id_pegawai' => $this->input->post('id_pegawai'),
			'jumlah_bayar' => $this->input->post('jumlah_bayar'),
			'tgl_pembayaran' => $this->input->post('tgl_pembayaran'),
			'keterangan_bayar' => $this->input->post('keterangan_bayar'),
		];
		$this->db->insert('data_pinjaman', $get);

		$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
		<strong>Data berhasil ditambahkan!</strong>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
		</button>
		</div>');
		redirect('pegawai/data_pinjaman');
	}

	/*
	public function update_data($id)
	{
		$data['data_pinjaman'] = $this->db->query("SELECT * FROM data_pinjaman JOIN data_pegawai ON data_pinjaman.id_pegawai = data_pegawai.id_pegawai WHERE id_pinjaman= '$id'")->result();

		$data['title'] = "Update Data Pinjaman";
		$where = array('id_pinjaman' => $id);

		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/update_dataPinjaman', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function update_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update_data();
		} else {
			$id				= $this->input->post('id_pinjaman');
			$id_pegawai		= $this->input->post('id_pegawai');
			$tgl_pembayaran	= $this->input->post('tgl_pembayaran');
			$jumlah_pembayaran		= $this->input->post('jumlah_pembayaran');
			$keterangan_pembayaran	= $this->input->post('keterangan_bayar');
			$photo			= $_FILES['photo']['name'];
			if ($photo = '') {
			} else {
				$config['upload_path'] 		= './photo/bukti_pembayaran';
				$config['allowed_types'] 	= 'jpg|jpeg|png|tiff';
				$config['max_size']			= 	2048;
				$config['file_name']		= 	'pembayaran-' . date('ymd') . '-' . substr(md5(rand()), 0, 10);
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('photo')) {
					echo "Photo Gagal Diupload !";
				} else {
					$photo = $this->upload->data('file_name');
				}
			}

			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_pembayaran' 	=> $tgl_pembayaran,
				'jumlah_pembayaran' 	=> $jumlah_pembayaran,
				'keterangan_bayar' 	=> $keterangan_pembayaran,
				'bukti_pinjaman' => $photo,

			);

			$where = array(
				'id_pinjaman' => $id
			);

			$this->ModelPenggajian->update_data('data_pinjaman', $data, $where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil diupdate!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('pegawai/data_pinjaman');
		}
	}


	public function update_data($id)
	{
		$where = array('id_pinjaman' => $id);
		$data['data_pinjaman'] = $this->db->query("SELECT * FROM data_pinjaman JOIN data_pegawai 
		ON data_pinjaman.id_pegawai = data_pegawai.id_pegawai WHERE id_pinjaman= '$id'")->result();

		$data['title'] = "Update Data Pinjaman";

		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/update_dataPinjaman', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function update_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update_data();
		} else {
			$id				= $this->input->post('id_pinjaman');
			$id_pegawai		= $this->input->post('id_pegawai');
			$tgl_pembayaran	= $this->input->post('tgl_pembayaran');
			$jumlah_bayar		= $this->input->post('jumlah_bayar');
			$keterangan_bayar	= $this->input->post('keterangan_bayar');
			$photo			= $_FILES['photo']['name'];
			if ($photo = '') {
			} else {
				$config['upload_path'] 		= './photo/bukti_pembayaran';
				$config['allowed_types'] 	= 'jpg|jpeg|png|tiff';
				$config['max_size']			= 	2048;
				$config['file_name']		= 	'pembayaran-' . date('ymd') . '-' . substr(md5(rand()), 0, 10);
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('photo')) {
					echo "Photo Gagal Diupload !";
				} else {
					$photo = $this->upload->data('file_name');
				}
			}



			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_pembayaran' 	=> $tgl_pembayaran,
				'jumlah_bayar' 	=> $jumlah_bayar,
				'keterangan_bayar' 	=> $keterangan_bayar,
				'bukti_pinjaman' => $photo,

			);

			$where = array(
				'id_pinjaman' => $id
			);

			$this->ModelPenggajian->update_data('data_pinjaman', $data, $where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
			<strong>Data berhasil diupdate!</strong>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button>
			</div>');
			redirect('pegawai/data_pinjaman');
		}
	}


	public function _rules()
	{
		$this->form_validation->set_rules('id_pegawai', 'Id Pegawai', 'required');
		$this->form_validation->set_rules('jumlah_pembayaran', 'Jumlah Pembayaran', 'required');
		$this->form_validation->set_rules('tgl_pembayaran', 'Tanggal Pembayaran', 'required');
		$this->form_validation->set_rules('keterangan_bayar', 'Keterangan Bayar', 'required');
	}
	*/

	public function index()
	{
		$data['title'] = "Data Pinjaman";
		$data['jabatan'] = $this->ModelPenggajian->get_data('data_jabatan')->result();


		$this->db->select('*');
		$this->db->from('data_pinjaman');
		$this->db->join('data_pegawai', 'data_pinjaman.id_pegawai=data_pegawai.id_pegawai ', 'inner');
		$data['data_pinjaman'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();
		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/data_pinjaman', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function tambah_data()
	{
		$data['title'] = "Tambah Data Pinjaman";
		$this->db->select('*');
		$this->db->from('data_pinjaman');
		$this->db->join('data_pegawai', 'data_pinjaman.id_pegawai=data_pegawai.id_pegawai ', 'inner');
		$data['data_pinjaman'] = $this->db->get()->result_array();
		$data['users'] = $this->db->get('data_pegawai')->result_array();

		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/tambah_dataPinjaman', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function tambah_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->tambah_data();
		} else {
			$id_pegawai	= $this->input->post('id_pegawai');
			$tgl_pinjaman		= $this->input->post('tgl_pinjaman');
			$jumlah_pinjaman	= $this->input->post('jumlah_pinjaman');
			$keterangan		= $this->input->post('keterangan');
			$photo			= $_FILES['photo']['name'];
			if ($photo = '') {
			} else {
				$config['upload_path'] 		= './photo/bukti_pinjaman';
				$config['allowed_types'] 	= 'jpg|jpeg|png|tiff';
				$config['max_size']			= 	2048;
				$config['file_name']		= 	'pinjaman-' . date('ymd') . '-' . substr(md5(rand()), 0, 10);
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('photo')) {
					echo "Photo Gagal Diupload !";
				} else {
					$photo = $this->upload->data('file_name');
				}
			}

			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_pinjaman' 	=> $tgl_pinjaman,
				'jumlah_pinjaman' 	=> $jumlah_pinjaman,
				'keterangan' 	=> $keterangan,
				'bukti_pinjaman' => $photo,
			);

			$this->ModelPenggajian->insert_data($data, 'data_pinjaman');
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil ditambahkan!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('pegawai/data_pinjaman');
		}
	}


	public function update_data($id)
	{
		$where = array('id_pinjaman' => $id);
		$data['data_pinjaman'] = $this->db->query("SELECT * FROM data_pinjaman JOIN data_pegawai ON data_pinjaman.id_pegawai = data_pegawai.id_pegawai WHERE id_pinjaman= '$id'")->result();

		$data['title'] = "Update Data Pinjaman";

		$this->load->view('template_pegawai/header', $data);
		$this->load->view('template_pegawai/sidebar');
		$this->load->view('pegawai/update_dataPinjaman', $data);
		$this->load->view('template_pegawai/footer');
	}

	public function update_data_aksi()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update_data();
		} else {
			$id				= $this->input->post('id_pinjaman');
			$id_pegawai		= $this->input->post('id_pegawai');
			$tgl_pembayaran	= $this->input->post('tgl_pembayaran');
			$jumlah_bayar		= $this->input->post('jumlah_bayar');
			$keterangan_bayar	= $this->input->post('keterangan_bayar');
			$photo			= $_FILES['photo']['name'];
			if ($photo = '') {
			} else {
				$config['upload_path'] 		= './photo/bukti_pembayaran';
				$config['allowed_types'] 	= 'jpg|jpeg|png|tiff';
				$config['max_size']			= 	2048;
				$config['file_name']		= 	'pembayaran-' . date('ymd') . '-' . substr(md5(rand()), 0, 10);
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('photo')) {
					echo "Photo Gagal Diupload !";
				} else {
					$photo = $this->upload->data('file_name');
				}
			}



			$data = array(
				'id_pegawai' 	=> $id_pegawai,
				'tgl_pembayaran' 	=> $tgl_pembayaran,
				'jumlah_bayar' 	=> $jumlah_bayar,
				'keterangan_bayar' 	=> $keterangan_bayar,
				'bukti_pembayaran' => $photo,

			);

			$where = array(
				'id_pinjaman' => $id
			);

			$this->ModelPenggajian->update_data('data_pinjaman', $data, $where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>Data berhasil diupdate!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
			redirect('pegawai/data_pinjaman');
		}
	}

	public function delete_data($id)
	{
		$where = array('id_pinjaman' => $id);
		$this->ModelPenggajian->delete_data($where, 'data_pinjaman');
		$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Data berhasil dihapus!</strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');
		redirect('pegawai/data_pinjaman');
	}

	public function _rules()
	{
		$this->form_validation->set_rules('id_pegawai', 'Id Pegawai', 'required');
		$this->form_validation->set_rules('tgl_pinjaman', 'Tgl Pinjaman', 'required');
		$this->form_validation->set_rules('jumlah_pinjaman', 'Jumlah Pinjaman', 'required');
		$this->form_validation->set_rules('keterangan_bayar', 'Keterangan Bayar', 'required');
	}
}
